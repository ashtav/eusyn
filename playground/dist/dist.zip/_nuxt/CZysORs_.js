import{V as s,B as o,S as a}from"./DNDMXCnN.js";const r=s((u,m)=>{const e=o(),t=a("theme");e.$e.theme.set(t.value||"system")});export{r as default};
