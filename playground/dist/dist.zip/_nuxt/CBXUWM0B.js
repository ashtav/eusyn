import{X as s,B as o,U as a}from"./CUMUyx1W.js";const r=s((u,m)=>{const e=o(),t=a("theme");e.$e.theme.set(t.value||"system")});export{r as default};
