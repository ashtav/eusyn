import{T as s,L as o,R as a}from"./BRK7ou47.js";const r=s((u,m)=>{const e=o(),t=a("theme");e.$e.theme.set(t.value||"system")});export{r as default};
