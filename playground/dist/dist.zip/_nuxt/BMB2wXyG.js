import{S as s,L as o,T as a}from"./DBlPRTKW.js";const r=s((u,m)=>{const e=o(),t=a("theme");e.$e.theme.set(t.value||"system")});export{r as default};
