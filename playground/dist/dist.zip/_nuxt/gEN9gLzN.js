import{_ as e,c as t,a as r}from"./B-NeRa6q.js";const c={setup(){return{}}};function n(o,s,a,p,_,d){return r(),t("div")}const i=e(c,[["render",n]]);export{i as default};
