import{U as s,K as o,S as a}from"./Bnil-BId.js";const r=s((u,m)=>{const e=o(),t=a("theme");e.$e.theme.set(t.value||"system")});export{r as default};
