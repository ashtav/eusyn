import{_ as e,c as t,o}from"./DiZFY1gu.js";const r={setup(){return{}}};function c(n,s,a,p,_,d){return o(),t("div")}const i=e(r,[["render",c]]);export{i as default};
