import{S as s,L as o,T as a}from"./B-NeRa6q.js";const r=s((u,m)=>{const e=o(),t=a("theme");e.$e.theme.set(t.value||"system")});export{r as default};
