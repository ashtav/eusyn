import{_ as e,a as t,c as r}from"./B2QH7UNX.js";const s={setup(){return{}}};function c(o,n,a,p,_,f){return t(),r("div")}const d=e(s,[["render",c]]);export{d as default};
