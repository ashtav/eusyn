import{U as s,B as o,R as a}from"./B2QH7UNX.js";const r=s((u,m)=>{const e=o(),t=a("theme");e.$e.theme.set(t.value||"system")});export{r as default};
